﻿using System;

namespace userstore1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (UserContext db = new UserContext())
            {
                // создаем два объекта User
                User user1 = new User { Name = "Krõpsud", Price = 2.19, Release = "25 april 2018" };
                User user2 = new User { Name = "Kartull", Price = 0.39, Release = "26 april 2018" };
                User user3 = new User { Name = "Cola-Cola", Price = 1.50, Release = "27 april 2018"};

                // добавляем их в бд
                db.Users.Add(user1);
                db.Users.Add(user2);
                db.Users.Add(user3);
                db.SaveChanges();
                Console.WriteLine("Objektid on lisatud ");

                // получаем объекты из бд и выводим на консоль
                var users = db.Users;
                Console.WriteLine("Objektide nimistu: ");
                foreach (User u in users)
                {
                    Console.WriteLine("{0}.{1} - {3}", u.Id, u.Name, u.Price, u.Release);
                }
            }
            Console.Read();
        }
    }
}

